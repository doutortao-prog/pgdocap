// Este componente foi descontinuado. 
// A funcionalidade de simulação de usuário foi integrada diretamente no Dashboard.tsx
// para melhor performance e manutenção.
const HiddenCaptainPage = () => null;
export default HiddenCaptainPage;