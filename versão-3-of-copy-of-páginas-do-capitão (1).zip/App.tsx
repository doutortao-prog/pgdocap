import React, { useState, useEffect } from 'react';
import LandingPage, { defaultPageConfig } from './components/LandingPage';
import Dashboard from './components/Dashboard';
import LoginModal from './components/LoginModal';
import { User, ViewState, Page, Plan, UserRole } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('landing');
  
  // Persistência do Usuário Logado
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('capitao_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [modalInitialView, setModalInitialView] = useState<'login' | 'register' | 'signup-free'>('login');

  // Persistência da Lista de Usuários (Base de Dados Mock)
  const [usersList, setUsersList] = useState<User[]>(() => {
    const saved = localStorage.getItem('capitao_users_db');
    if (saved) return JSON.parse(saved);
    
    // Dados Iniciais de Exemplo
    return [
      { username: 'admin', role: UserRole.ADMIN, name: 'Administrador', email: 'admin@capitao.com', status: 'active', joinedAt: '2023-01-15' },
      { username: 'user', role: UserRole.USER, name: 'Cliente Vip', email: 'vip@cliente.com', plan: 'Capitão', status: 'active', joinedAt: '2023-06-20', phone: '(11) 99999-0000' },
      { username: 'capitao', role: UserRole.USER, name: 'Capitão Usuário', email: 'capitao@mar.com', plan: 'Almirante', status: 'active', joinedAt: '2023-08-10' },
      { username: 'teste', role: UserRole.FREE_USER, name: 'Usuário Teste', email: 'teste@free.com', status: 'active', joinedAt: '2023-10-05' }
    ];
  });

  // Persistência das Páginas
  const [pages, setPages] = useState<Page[]>(() => {
    const saved = localStorage.getItem('capitao_pages');
    if (saved) return JSON.parse(saved);
    
    return [{ 
      id: 1, 
      title: "Páginas do Capitão", 
      thumbnail: "https://picsum.photos/400/250?random=100", 
      url: "/p/paginas-do-capitao", 
      status: "published", 
      lastModified: "Sistema", 
      config: defaultPageConfig 
    }];
  });

  // Persistência dos Planos
  const [plans, setPlans] = useState<Plan[]>(() => {
    const saved = localStorage.getItem('capitao_plans');
    if (saved) return JSON.parse(saved);
    
    return [
      {
        id: 'weekly',
        name: 'Marinheiro',
        price: 'R$ 27',
        period: '/semana',
        description: 'Ideal para testes rápidos e lançamentos pontuais.',
        features: ['1 Landing Page Ativa', 'Editor Visual Básico', 'Hospedagem Inclusa', 'Suporte via Email'],
        color: 'bg-blue-500',
        popular: false,
        active: true
      },
      {
        id: 'monthly',
        name: 'Capitão',
        price: 'R$ 97',
        period: '/mês',
        description: 'O plano favorito. Potência total para seu negócio escalar.',
        features: ['5 Landing Pages Ativas', 'IA Geradora de Copy', 'Editor Avançado', 'Domínio Personalizado', 'Suporte Prioritário'],
        color: 'bg-indigo-600',
        popular: true,
        active: true
      },
      {
        id: 'annual',
        name: 'Almirante',
        price: 'R$ 997',
        period: '/ano',
        description: 'Economia máxima e acesso vitalício a novas features.',
        features: ['Páginas Ilimitadas', 'IA Ilimitada', 'Consultoria de Conversão', 'Acesso a Beta Features', 'Gerente de Conta'],
        color: 'bg-slate-800',
        popular: false,
        active: true
      }
    ];
  });

  // Efeitos para Salvar Dados
  useEffect(() => { localStorage.setItem('capitao_pages', JSON.stringify(pages)); }, [pages]);
  useEffect(() => { localStorage.setItem('capitao_plans', JSON.stringify(plans)); }, [plans]);
  useEffect(() => { localStorage.setItem('capitao_users_db', JSON.stringify(usersList)); }, [usersList]);
  
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('capitao_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('capitao_user');
    }
  }, [currentUser]);

  const handleLogin = (user: User) => {
    // Em um app real, validaríamos contra o banco de dados aqui. 
    // Como é mock, apenas setamos o usuário logado.
    // Mas podemos atualizar a lista se for um novo cadastro.
    const existingUser = usersList.find(u => u.username === user.username);
    if (!existingUser) {
      const newUser = { ...user, status: 'active', joinedAt: new Date().toISOString().split('T')[0] } as User;
      setUsersList([...usersList, newUser]);
      setCurrentUser(newUser);
    } else {
      setCurrentUser(existingUser);
    }
    
    setCurrentView('dashboard');
    setIsLoginModalOpen(false);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('landing');
  };

  const openLogin = () => { setModalInitialView('login'); setIsLoginModalOpen(true); };
  const openPricing = () => { setModalInitialView('register'); setIsLoginModalOpen(true); };
  const openSignupFree = () => { setModalInitialView('signup-free'); setIsLoginModalOpen(true); };
  const closeLogin = () => { setIsLoginModalOpen(false); };

  const handleSimulateUser = () => { setCurrentView('hidden-captain'); };
  const handleBackToAdmin = () => { setCurrentView('dashboard'); };

  // Encontra a configuração da página principal (ID 1) para exibir no frontend
  const homePageConfig = pages.find(p => p.id === 1)?.config || defaultPageConfig;

  return (
    <div className="antialiased text-gray-900 bg-gray-50 min-h-screen">
      {currentView === 'landing' && (
        <>
          <LandingPage 
            onOpenLogin={openLogin} 
            onOpenPricing={openPricing}
            onOpenSignupFree={openSignupFree} 
            config={homePageConfig} 
          />
          <LoginModal 
            isOpen={isLoginModalOpen} 
            onClose={closeLogin} 
            onLogin={handleLogin} 
            plans={plans}
            initialView={modalInitialView}
          />
        </>
      )}

      {currentView === 'dashboard' && currentUser && (
        <Dashboard 
          user={currentUser} 
          onLogout={handleLogout} 
          pages={pages}
          setPages={setPages}
          plans={plans}
          setPlans={setPlans}
          usersList={usersList} // Passando a lista
          setUsersList={setUsersList} // Passando o setter
          onSimulateUser={handleSimulateUser}
        />
      )}

      {/* Reutiliza o Dashboard com a flag isSimulating para a visão oculta */}
      {currentView === 'hidden-captain' && currentUser && (
        <Dashboard
          user={currentUser}
          onLogout={handleLogout}
          pages={pages}
          setPages={setPages}
          plans={plans}
          setPlans={setPlans}
          usersList={usersList} // Passando para manter consistência, embora não usado no modo simulação
          setUsersList={setUsersList}
          isSimulating={true}
          onExitSimulation={handleBackToAdmin}
        />
      )}
    </div>
  );
};

export default App;